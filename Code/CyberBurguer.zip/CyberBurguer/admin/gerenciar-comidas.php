<!--Aqui o menu será inserido-->
<?php include('uteis/menu.php'); ?>
<head>
    <title>CyberFood - Cardápio</title>
</head>
            <div class="conteudo">
            <div class="corpo">
                <h1>Gerenciar Cardápio</h1>

                <br><br>

                <?php
                    if(isset($_SESSION['salvar']))
                    {
                        echo $_SESSION['salvar'];
                        unset ($_SESSION['salvar']);
                    }
                    if(isset($_SESSION['delete'])){
                        echo $_SESSION['delete'];
                        unset($_SESSION['delete']);
                    }
                    if(isset($_SESSION['falha-remove']))
                    {
                        echo $_SESSION['falha-remove'];
                        unset($_SESSION['falha-remove']);
                    }
                    if(isset($_SESSION['editar']))
                    {
                        echo $_SESSION['editar'];
                        unset($_SESSION['editar']);
                    }
                    if(isset($_SESSION['upload']))
                    {
                        echo $_SESSION['upload'];
                        unset($_SESSION['upload']);
                    }
                    
                ?>

                <a href="../admin/add-comida.php" class="btn-primario">Adicionar Comida</a>

                <br><br><br>    
                
                <table class="tabela">
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Preço</th>
                        <th>Imagem</th>
                        <th>Apresentar</th>
                        <th>Ativo</th>
                        <th>Ações</th>
                    </tr>

                    <?php
                            $sn = 1;
                            $sql = "SELECT * FROM tab_comidas";
                            $res = mysqli_query($conn, $sql);

                            if($res == TRUE){
                                $count = mysqli_num_rows($res);

                                if($count>0)
                                {
                                    while($rows=mysqli_fetch_assoc($res))
                                    {
                                        $id=$rows['id'];
                                        $titulo = $rows['titulo'];
                                        $descricao = $rows['descricao'];
                                        $preco = $rows['preco'];
                                        $nome_imagem = $rows['nome_imagem'];
                                        $apresentar = $rows['apresentar'];
                                        $ativo = $rows['ativo'];


                                        //Mostrando as informações
                                        ?>
                                        <tr>
                                            <td><?php echo $sn++; ?></td>

                                            <td><?php echo $titulo; ?></td>
                                            

                                            <td>R$<?php echo $preco; ?></td>

                                            <td><?php 
                                                if($nome_imagem!="")
                                                {   ?>
                                                    <img src="<?php echo SITEURL; ?>image/comidas/<?php echo $nome_imagem; ?>" width="100px">
                                                    <?php
                                                }
                                                else
                                                {
                                                    echo "<div class='erro'>Imagem não Adicionada </div>";
                                                }
                                            
                                            ?>
                                            </td>

                                            <td><?php echo $apresentar ?></td>

                                            <td><?php echo $ativo ?></td>
                                            <td>
                                                <a href="<?php echo SITEURL ?>admin/editar-comida.php?id=<?php echo $id;?>&nome_imagem=<?php echo $nome_imagem; ?>" class="btn-secundario">Editar</a>
                                                <a href="<?php echo SITEURL ?>admin/excluir-comida.php?id=<?php echo $id;?>&nome_imagem=<?php echo $nome_imagem; ?>" class="btn-danger">Excluir</a>
                                            </td>
                                        </tr>
                                            
                                            
                                        
                                        <?php
                                        
                                        
                                    }
                                }
                                else
                                {

                                }
                            }
                    ?>
                    
                </table>

        </div>

        </div>

<!--Já aqui o rodapé será inserido-->
<?php include('uteis/rodape.php'); ?>