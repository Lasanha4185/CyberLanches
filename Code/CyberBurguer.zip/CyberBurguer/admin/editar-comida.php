<?php
    include('../admin/uteis/menu.php');
    include('../admin/uteis/rodape.php');
?>

<head><title>Editar Comida</title></head>

<?php
    // Início da lógica PHP
    if(isset($_GET['id'])) {
        $id = $_GET['id'];

        // Verifica se a comida existe
        $sql2 = "SELECT * FROM tab_comidas WHERE id=$id";
        $res2 = mysqli_query($conn, $sql2);
        $count = mysqli_num_rows($res2);

        if($count == 1) {
            $row2 = mysqli_fetch_assoc($res2);
            $titulo = $row2['titulo'];
            $descricao = $row2['descricao'];
            $preco = $row2['preco'];
            $categoria_atual = $row2['categoria_id'];
            $imagem_atual = $row2['nome_imagem'];
            $apresentar = $row2['apresentar'];
            $ativo = $row2['ativo'];
        } else {
            $_SESSION['comida-nao-encontrada'] = "<div class='erro'>Comida não Encontrada<br><br></div>";
            header('location:'.SITEURL.'admin/gerenciar-comidas.php');
            exit();
        }
    } else {
        header('location:'.SITEURL.'admin/gerenciar-comidas.php');
        exit();
    }

    // Processa o formulário de edição
    if(isset($_POST['editar-comida'])) {
        $id = $_POST['id'];
        $titulo = $_POST['titulo'];
        $descricao = $_POST['descricao'];
        $preco = $_POST['preco'];
        $imagem_atual = $_POST['imagem_atual'];
        $categoria = $_POST['categoria'];
        $apresentar = $_POST['apresentar'];
        $ativo = $_POST['ativo'];

        // Verifica se foi feita uma nova imagem
        if(isset($_FILES['imagem']['name'])) {
            $imagem_nome = $_FILES['imagem']['name'];

            if($imagem_nome != "") {
                $partes = explode('.', $imagem_nome);
                $ext = end($partes);

                $imagem_nome = "Comidas".rand(000, 999).'.'.$ext;
                $caminho = $_FILES['imagem']['tmp_name'];
                $destino = "../image/comidas/".$imagem_nome;

                $salvar = move_uploaded_file($caminho, $destino);

                if($salvar == FALSE) {
                    $_SESSION['upload'] = "<div class='erro'>Erro ao Salvar Imagem <br><br><br></div>";
                    header('location:'.SITEURL.'admin/gerenciar-comidas.php');
                    exit();
                }

                // Remove a imagem atual se houver uma nova imagem
                if($imagem_atual != "") {
                    $remove_caminho = "../image/comidas/".$imagem_atual;
                    $remove = unlink($remove_caminho);

                    if($remove == FALSE) {
                        $_SESSION['falha-remove'] = "<div class='erro'>Falha ao Editar Imagem Atual<br><br><br></div>";
                        header('location:'.SITEURL.'admin/gerenciar-comidas.php');
                        exit();
                    }
                }
            } else {
                $imagem_nome = $imagem_atual;
            }
        } else {
            $imagem_nome = $imagem_atual;
        }

        $sql2 = "UPDATE tab_comidas SET 
                    titulo = '$titulo',
                    descricao = '$descricao',
                    preco = '$preco',
                    nome_imagem = '$imagem_nome',
                    categoria_id = '$categoria',
                    apresentar = '$apresentar',
                    ativo = '$ativo'
                WHERE id=$id";

        $res2 = mysqli_query($conn, $sql2);

        if($res2 == TRUE) {
            $_SESSION['editar'] = "Comida Editada com Sucesso";
            header('location:'.SITEURL.'admin/gerenciar-comidas.php');
        } else {
            $_SESSION['editar'] = "<div class='erro'>Falha ao Editar Comida</div>";
            header('location:'.SITEURL.'admin/gerenciar-comidas.php');
        }
        exit();
    }
?>

<div class="conteudo">
    <div class="corpo">
        <h1>Editar Comida</h1>

        <form action="" method="POST" enctype="multipart/form-data">
        <table class="tabela-30">
                <tr>
                    <td>Nome: </td>
                    <td>
                        <div class="form">
                            <input type="text" name="titulo" value="<?php echo $titulo ?>" class="input">
                            <span class="input-border"></span>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>Descrição: </td>
                    <td>
                        <div class="form">
                            <textarea class="input" name="descricao" cols="30" rows="10"><?php echo $descricao; ?></textarea>
                            <span class="input-border"></span>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>Preço: </td>
                    <td>
                        <div class="form">
                            <input type="number" name="preco" value="<?php echo $preco; ?>" class="input">
                            <span class="input-border"></span>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>Imagem Atual</td>
                    <td>
                        <?php if($imagem_atual != "") { ?>
                            <img src="<?php echo SITEURL; ?>image/comidas/<?php echo $imagem_atual; ?>" width="150px">
                        <?php } ?>
                    </td>
                </tr>

                <tr>
                    <td>Nova Imagem</td>
                    <td>
                        <input type="file" name="imagem">
                    </td>
                </tr>

                <tr>
                    <td>Categoria: </td>
                    <td>
                        <select name="categoria">
                            <?php
                                $sql = "SELECT * FROM tab_categorias WHERE ativo = 'Sim'";
                                
                                $res = mysqli_query($conn, $sql);
                                $count = mysqli_num_rows($res);

                                if($count > 0) {
                                    while($row = mysqli_fetch_assoc($res)) {
                                        $categoria_id = $row['id'];
                                        $categoria_titulo = $row['titulo'];
                                    ?>
                                        <option <?php if($categoria_atual==$categoria_id){echo "selected";}?>  value="<?php echo $categoria_id ?>"><?php echo $categoria_titulo ?></option>
                                        <?php
                                    }
                                } else {
                                    echo "<option value=\"0\">Categoria Não Encontrada</option>";
                                }
                            ?>
                        </select>
                    </td>
                </tr>


                <tr>
                    <td>Apresentar: </td>
                    <td>
                        <input <?php if($apresentar == "Sim") { echo "checked"; } ?> type="radio" name="apresentar" value="Sim"> Sim
                        <input <?php if($apresentar == "Não") { echo "checked"; } ?> type="radio" name="apresentar" value="Não"> Não
                    </td>
                </tr>

                <tr>
                    <td>Ativo: </td>
                    <td>
                        <input <?php if($ativo == "Sim") { echo "checked"; } ?> type="radio" name="ativo" value="Sim"> Sim
                        <input <?php if($ativo == "Não") { echo "checked"; } ?> type="radio" name="ativo" value="Não"> Não
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="hidden" name="imagem_atual" value="<?php echo $imagem_atual; ?>">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="editar-comida" value="Salvar" class="btn-primario">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
