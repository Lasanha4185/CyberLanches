<!--Aqui o menu será inserido-->
<?php include('uteis/menu.php'); ?>
<head>
    <title>CyberFood - Pedidos</title>
</head>
            <div class="conteudo">
            <div class="corpo">
                <h1>Gerenciar Pedidos</h1>

                <br><br>

                <?php
                    if(isset($_SESSION['salvar']))
                    {
                        echo $_SESSION['salvar'];
                        unset ($_SESSION['salvar']);
                    }
                    if(isset($_SESSION['delete'])){
                        echo $_SESSION['delete'];
                        unset($_SESSION['delete']);
                    }
                    if(isset($_SESSION['falha-remove']))
                    {
                        echo $_SESSION['falha-remove'];
                        unset($_SESSION['falha-remove']);
                    }
                    if(isset($_SESSION['editar']))
                    {
                        echo $_SESSION['editar'];
                        unset($_SESSION['editar']);
                    }
                    if(isset($_SESSION['upload']))
                    {
                        echo $_SESSION['upload'];
                        unset($_SESSION['upload']);
                    }
                    
                ?>

                <br><br><br>    
                
                <table class="tabela">
                    <tr>
                        <th>ID</th>
                        <th>Comida</th>
                        <th>Quantidade</th>
                        <th>Total</th>
                        <th>Data do Pedido</th>
                        <th>Nome do Cliente</th>
                        <th>Contato</th>
                        <th>Endereço</th>
                        <th>Ação</th>
                    </tr>

                    <?php
                            $sn = 1;
                            $sql = "SELECT * FROM tab_pedido";
                            $res = mysqli_query($conn, $sql);

                            if($res == TRUE){
                                $count = mysqli_num_rows($res);

                                if($count>0)
                                {
                                    while($rows=mysqli_fetch_assoc($res))
                                    {
                                        $id=$rows['id'];
                                        $comida = $rows['comida'];
                                        $total = $rows['total'];
                                        $data = $rows['data_pedido'];
                                        $quantidade = $rows['quantidade'];
                                        $status = $rows['status'];
                                        $nome_cliente = $rows['nome_cliente'];
                                        $cliente_contato = $rows['cliente_contato'];
                                        $cliente_endereco = $rows['cliente_endereco'];



                                        //Mostrando as informações
                                        ?>
                                        <tr>
                                            <td><?php echo $sn++; ?></td>

                                            <td><?php echo $comida; ?></td>
                                            

                                            <td><?php echo $quantidade; ?></td>

                                            <td>R$<?php echo $total; ?></td>

                                            <td><?php echo $data; ?></td>


                                            <td><?php echo $nome_cliente; ?></td>

                                            <td><?php echo $cliente_contato; ?></td>

                                            <td><?php echo $cliente_endereco;  ?></td>
                                            <td>
                                                <a href="<?php echo SITEURL ?>admin/excluir-pedido.php?id=<?php echo $id;?>" class="btn-danger">Excluir</a>
                                            </td>
                                        </tr>
                                            
                                            
                                        
                                        <?php
                                        
                                        
                                    }
                                }
                                else
                                {

                                }
                            }
                    ?>
                    
                </table>

        </div>

        </div>

<!--Já aqui o rodapé será inserido-->
<?php include('uteis/rodape.php'); ?>