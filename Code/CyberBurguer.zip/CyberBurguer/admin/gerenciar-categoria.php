<!--Aqui o menu será inserido-->
<?php include('uteis/menu.php'); ?>
<head>
    <title>CyberFood - Categorias</title>
</head>
            <div class="conteudo">
            <div class="corpo">
                <h1>Gerenciar Categorias</h1>
                
                <br><br>

                <?php
            if(isset($_SESSION['add']))
            {
                echo $_SESSION['add'];
                unset ($_SESSION['add']);
            }

            if(isset($_SESSION['remove']))
            {
                echo $_SESSION['remove'];
                unset($_SESSION['remove']);
            }
            if(isset($_SESSION['delete']))
            {
                echo $_SESSION['delete'];
                unset($_SESSION['delete']);
            }
            if(isset($_SESSION['categoria-nao-encontrada']))
            {
                echo $_SESSION['categoria-nao-encontrada'];
                unset($_SESSION['categoria-nao-encontrada']);
            }
            if(isset($_SESSION['editar']))
            {
                echo $_SESSION['editar'];
                unset($_SESSION['editar']);
            }
            if(isset($_SESSION['upload']))
            {
                echo $_SESSION['upload'];
                unset($_SESSION['upload']);
            }
            if(isset($_SESSION['falha-remove']))
            {
                echo $_SESSION['falha-remove'];
                unset($_SESSION['falha-remove']);
            }

        ?>

                <a href="<?php echo SITEURL;?>admin/add-categoria.php" class="btn-primario">Adicionar Categoria</a>

                <br><br><br>

                
                <table class="tabela">
                    <tr>
                        <th>ID</th>
                        <th>Categoria</th>
                        <th>Imagem</th>
                        <th>Apresentar</th>
                        <th>Ativo</th>
                    </tr>
                    <?php
                            $sn = 1;
                            $sql = "SELECT * FROM tab_categorias";
                            $res = mysqli_query($conn, $sql);

                            if($res == TRUE){
                                $count = mysqli_num_rows($res);

                                if($count>0)
                                {
                                    while($rows=mysqli_fetch_assoc($res))
                                    {
                                        $id=$rows['id'];
                                        $titulo = $rows['titulo'];
                                        $nome_imagem = $rows['nome_imagem'];
                                        $apresentar = $rows['apresentar'];
                                        $ativo = $rows['ativo'];


                                        //Mostrando as informações
                                        ?>
                                        <tr>
                                            <td><?php echo $sn++; ?></td>

                                            <td><?php echo $titulo ?></td>

                                            <td><?php 
                                                if($nome_imagem!="")
                                                {   ?>
                                                    <img src="<?php echo SITEURL; ?>image/categorias/<?php echo $nome_imagem; ?>" width="100px">
                                                    <?php
                                                }
                                                else
                                                {
                                                    echo "<div class='erro'>Imagem não Adicionada </div>";
                                                }
                                            
                                            ?>
                                            </td>

                                            <td><?php echo $apresentar ?></td>

                                            <td><?php echo $ativo ?></td>
                                            <td>
                                                <a href="<?php echo SITEURL ?>admin/editar-categoria.php?id=<?php echo $id;?>&nome_imagem=<?php echo $nome_imagem; ?>" class="btn-secundario">Editar</a>
                                                <a href="<?php echo SITEURL ?>admin/excluir-categoria.php?id=<?php echo $id;?>&nome_imagem=<?php echo $nome_imagem; ?>" class="btn-danger">Excluir</a>
                                            </td>
                                        </tr>
                                            
                                            
                                        
                                        <?php
                                        
                                        
                                    }
                                }
                                else
                                {

                                }
                            }
                    ?>


                    
                </table>

        </div>
        </div>

<!--Já aqui o rodapé será inserido-->
<?php include('uteis/rodape.php'); ?>