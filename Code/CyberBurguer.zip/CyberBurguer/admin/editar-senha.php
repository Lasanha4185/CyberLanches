<?php
    include('uteis/menu.php');
    include('uteis/rodape.php');
?>

<div class="conteudo">
    <div class="corpo">
        <h1>Editar Senha</h1>

        <br><br>

        <?php
            if(isset($_GET['id']))
            {
                $id = $_GET['id'];
            }
        ?>

        <form action="" method="POST">

            <table class="tabela-30">
                    <tr>
                        <td>Senha Atual: </td>
                        <td>
                            <div class="form">
                                <input class="input" name="senha_antiga"  type="password" placeholder="Insira a Senha Antiga" required>
                                <span class="input-border"></span>
                            </div></td>
                    </tr>
                    <tr>
                        <td>Senha Nova: </td>
                        <td>
                            <div class="form">
                                <input class="input" name="senha_nova"  type="password" placeholder="Insira a Senha Nova" required>
                                <span class="input-border"></span>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Confirme a Senha: </td>
                        <td>
                            <div class="form">
                                <input class="input" name="confirmar_senha"  type="password" placeholder="Confirme a Senha" required>
                                <span class="input-border"></span>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td colspan="2">
                                <input type="hidden" name="id" value="<?php echo $id; ?>">
                                <input type="submit" name="confirmar" value="Editar" class="btn-primario">
                        </td>
                    </tr>

            </table>

        </form>


    </div>

</div>

<?php

if(isset($_POST['confirmar']))
    {
        $id = $_POST['id'];
        $senha_atual = $_POST['senha_antiga'];
        $nova_senha = $_POST['senha_nova'];
        $confirme_senha = $_POST['confirmar_senha'];

        $sql = "SELECT * FROM tab_admin WHERE id = $id AND senha = '$senha_atual'";

        $res = mysqli_query($conn, $sql);

        if($res == TRUE)
        {
            $count = mysqli_num_rows($res);

            if($count == 1)
            {
                if($nova_senha===$confirme_senha)
                {
                    $sql2 = "UPDATE tab_admin SET
                    senha = '$nova_senha'
                    WHERE id = $id
                    ";

                    $res2 = mysqli_query($conn, $sql2);

                    if($res2 ==TRUE)
                    {
                        $_SESSION['senha-trocada'] = "Senha Trocada com Sucesso";
                        header('location:'.SITEURL.'admin/pagina-admin.php');
                    }
                    else
                    {
                        $_SESSION['erro-senha'] = "<div class = 'erro'>Erro ao Trocas Senha</div>";
                        header('location:'.SITEURL.'admin/pagina-admin.php');
                    }
                }
                else
                {
                    $_SESSION['senha-nao-bate'] = "<div class = 'erro'>Senhas não Batem</div>";
                    header('location:'.SITEURL.'admin/pagina-admin.php');
                }
            }
            else
            {
                $_SESSION['usuario-nao-encontrado'] = "<div class = 'erro'>Usuário não Encontrado </div>";
                header('location:'.SITEURL.'admin/pagina-admin.php');
            }
        }
    }

?>