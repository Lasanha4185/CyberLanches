<?php
    include('../admin/config/conexao.php');
    session_destroy();
    header('location:'.SITEURL.'admin/login.php');

?>