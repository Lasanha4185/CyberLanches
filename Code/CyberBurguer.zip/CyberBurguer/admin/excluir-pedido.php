<?php
    include('../admin/config/conexao.php');

    if(isset($_GET['id']))
    {
        $id = $_GET['id'];

        $sql = "DELETE FROM tab_pedido WHERE id = $id";

        $res = mysqli_query($conn, $sql);

        if($res == TRUE)
        {
            $_SESSION['delete'] = "Deletado com Sucesso<br>";

            header('location:'.SITEURL.'admin/gerenciar-pedidos.php');

        }
        else
        {
            $_SESSION['delete'] = "<div class='erro'>Erro ao Excluir<br></div>";

            header('location:'.SITEURL.'admin/gerenciar-pedidos.php');
        }

    }
    else
    {
        header('location:'.SITEURL.'admin/gerenciar-pedidos.php');
    }
?>