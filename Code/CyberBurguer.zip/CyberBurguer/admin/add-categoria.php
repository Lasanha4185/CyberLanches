<?php
    include('../admin/uteis/menu.php');
    include('../admin/uteis/rodape.php');
?>

<head>
    <title>Adicionar Categoria</title>
</head>

<div class="conteudo">
    <div class="corpo">
        <h1>Adicionar Categoria</h1>

        <br><br>

        <?php
            if(isset($_SESSION['add']))
            {
                echo $_SESSION['add'];
                unset ($_SESSION['add']);
            }
            if(isset($_SESSION['salvar']))
            {
                echo $_SESSION['salvar'];
                unset ($_SESSION['salvar']);
            }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">

            <table class="tabela-30">
                <tr>
                    <td>Categoria: </td>
                    <td>
                            <div class="form">
                                <input class="input" name="titulo" placeholder="Insira o Nome da Categoria" type="text" required>
                                <span class="input-border"></span>
                            </div>
                    </td>
                </tr>

                <tr>
                    <td>
                        <input type="file" name="imagem">
                    </td>
                </tr>

                <tr>
                    <td>Apresentar: </td>
                    <td>
                        <input type="radio" name="apresentar" value="Sim"> Sim
                        <input type="radio" name="apresentar" value="Não">  Não
                    </td>
                </tr>

                <tr>
                    <td>Ativo: </td>
                    <td>
                        <input type="radio" name="ativo" value="Sim"> Sim
                        <input type="radio" name="ativo" value="Não">  Não
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                            <input type="hidden" name="id" value="<?php echo $id; ?>">
                            <input type="submit" name="categoria-salvar" value="Salvar" class="btn-primario">
                    </td>
                </tr>

            </table>

        </form>

        <?php
            if(isset($_POST['categoria-salvar']))
            {
                $titulo = $_POST['titulo'];
                if(isset($_POST['apresentar']))
                {
                    $apresentar = $_POST['apresentar'];
                }
                else
                {
                    $apresentar = "Não";
                }
                if(isset($_POST['ativo']))
                {
                    $ativo = $_POST['ativo'];
                }
                else
                {
                    $ativo = "Não";
                }
                if(isset($_FILES['imagem']['name']))
                {

                    $imagem_nome = $_FILES['imagem']['name'];

                    if($imagem_nome != "")
                    {
                        $partes = explode('.', $imagem_nome);
                        $ext = end($partes);

                        $imagem_nome = "Categoria_".rand(000, 999).'.'.$ext;

                        $caminho = $_FILES['imagem']['tmp_name'];


                        $destino = "../image/categorias/".$imagem_nome;

                        $salvar = move_uploaded_file($caminho, $destino);   

                        if($salvar==FALSE)
                        {
                            $_SESSION['upload'] = "<div class='erro'>Erro ao Salvar Imagem </div>";
                            header('location:'.SITEURL.'admin/add-categoria');
                            die();
                        }
                    }
                    

                    
                }


                $sql = "INSERT INTO tab_categorias SET
                titulo = '$titulo',
                nome_imagem = '$imagem_nome',
                apresentar = '$apresentar',
                ativo = '$ativo'
                ";

                $res = mysqli_query($conn, $sql);
                if($res==TRUE)
                {
                    $_SESSION['add'] = "Categoria Adicionada com Sucesso";
                    header('location:'.SITEURL.'admin/gerenciar-categoria.php');
                }    
                else
                {
                    $_SESSION['add'] = "<div class='erro'>Erro ao Adicionar Categoria</div>";
                    header('location:'.SITEURL.'admin/add-categoria.php');
                }


                
            }
        ?>

    </div>
</div>
