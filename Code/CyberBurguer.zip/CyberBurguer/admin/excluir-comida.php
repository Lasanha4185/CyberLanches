<?php
    include('../admin/config/conexao.php');

    if(isset($_GET['id']) AND isset($_GET['nome_imagem']))
    {
        $id = $_GET['id'];
        $nome_imagem = $_GET['nome_imagem'];

        if($nome_imagem !="")
        {
            $caminho = "../image/comidas/".$nome_imagem;
            $remove = unlink($caminho);

            if($remove==FALSE)
            {
                $_SESSION['remove'] = "<div class='erro'>Erro ao Remover<br><br></div>";

                header('location:'.SITEURL.'admin/gerenciar-comidas.php');

                die();

            }
        }

        $sql = "DELETE FROM tab_comidas WHERE id = $id";

        $res = mysqli_query($conn, $sql);

        if($res == TRUE)
        {
            $_SESSION['delete'] = "Deletado com Sucesso<br>";

            header('location:'.SITEURL.'admin/gerenciar-comidas.php');

        }
        else
        {
            $_SESSION['delete'] = "<div class='erro'>Erro ao Excluir<br></div>";

            header('location:'.SITEURL.'admin/gerenciar-comidas.php');
        }

    }
    else
    {
        header('location:'.SITEURL.'admin/gerenciar-comidas.php');
    }
?>