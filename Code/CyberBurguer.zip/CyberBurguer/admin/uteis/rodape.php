<div class="rodape ">
            <div class="rodape corpo centralizar fixar-rodape">
                <p class="rodape centralizar">2024 Todos os Direitos Reservados, CyberFood</p>
            </div>
        </div>

    </body>
</html>