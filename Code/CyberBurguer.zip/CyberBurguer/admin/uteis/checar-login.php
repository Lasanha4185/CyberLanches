<?php
    if(!isset($_SESSION['usuario'])){
        $_SESSION['mensagem-login'] = "<div class = 'erro'>Efetue o Login para Acessar o Painel de Controle<br><br><br></div>";
        header('location:'.SITEURL.'admin/login.php');
    }
?>