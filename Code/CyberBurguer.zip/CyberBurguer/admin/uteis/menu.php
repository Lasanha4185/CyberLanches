<?php 

    include('config/conexao.php');
    include('checar-login.php') 

?>


<html lang="pt-br">
    <head>
        <link rel="stylesheet" href="../css/admin.css">
    </head>
    
    <body>
        <div class="menu">
            <div class="corpo centralizar menu">
                <ul>
                    <li><a href="../admin/index.php">Home</a></li>
                    <li><a href="../admin/pagina-admin.php">Administrador</a></li>
                    <li><a href="../admin/gerenciar-categoria.php">Categorias</a></li>
                    <li><a href="../admin/gerenciar-comidas.php">Cardápio</a></li>
                    <li><a href="../admin/gerenciar-pedidos.php">Pedidos</a></li>
                    <li><a href="../admin/logout.php">Sair</a></li>
                </ul>
            </div>
        </div>
