<?php include('uteis/menu.php'); ?>
<head>
    <title>Adicionar Administrador</title>
</head>
    
<div class="conteudo">
        <div class="corpo">
        <h1>Adicionar Administrador</h1>
        <br><br>
            <form action="" method="POST">

                <table class="tabela-30">
                    <tr>
                        <td>Nome Completo: </td>
                        <td>
                            <div class="form">
                                <input class="input" name="nome" placeholder="Insira o Nome Completo"  type="text" required>
                                <span class="input-border"></span>
                            </div></td>
                    </tr>
                    <tr>
                        <td>Nome do Usuário: </td>
                        <td>
                            <div class="form">
                                <input class="input" placeholder="Insira o Nome do Usuário" name="usuario"  type="text" required>
                                <span class="input-border"></span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>Senha: </td>
                        <td>
                            <div class="form">
                                <input class="input" placeholder="Insira a Senha" name="senha" type="password" required>
                                <span class="input-border"></span>
                            </div>
                        </td>
                            
                    </tr>

                    <tr>
                        <td colspan="2">
                                <input type="submit" name="confirmar" value="Adicionar" class="btn-primario">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>

<?php include('uteis/rodape.php'); ?>

<?php
    
    if(isset($_POST['confirmar'])){
        //Obter os dados
        echo '11';
        $nome_completo = $_POST['nome'];
        $nome_user = $_POST['usuario'];
        $senha = $_POST['senha'];

        //Salvar os dados no SQL
        $sql = "INSERT INTO tab_admin SET
            nome_completo = '$nome_completo',
            nome_user = '$nome_user',
            senha = '$senha'
        ";

        
        $res = mysqli_query($conn, $sql) or die(mysqli_error());

        if($res==TRUE){
            //echo "Data Inserida";
            $_SESSION['add'] = "Administrador Adicionado com Sucesso";
            header("location:".SITEURL.'admin/pagina-admin.php');
        }
        else{
            //echo "Erro ao Inserir";
            $_SESSION['add'] = "Falha ao Adicionar Administrador";
            header("location:".SITEURL.'/add-admin.php');
        }
    }

?>