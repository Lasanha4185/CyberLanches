<?php
    include('../admin/uteis/menu.php');
    include('../admin/uteis/rodape.php');
?>
<head>
    <title>Adicionar Comida</title>
</head>

<div class="conteudo">
    <div class="corpo">
        <h1>Adicionar Comida</h1>

        <br><br>

        <?php
            if(isset($_SESSION['salvar'])) {
                echo $_SESSION['salvar'];
                unset ($_SESSION['salvar']);
            }
        ?>

        <form action="" method="POST" enctype="multipart/form-data">
            <table class="tabela-30">
                <tr>
                    <td>Nome: </td>
                    <td>
                        <div class="form">
                            <input type="text" name="nome_comida" placeholder="Insira o Nome" class="input">
                            <span class="input-border"></span>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>Descrição: </td>
                    <td>
                        <div class="form">
                            <textarea class="input" name="descricao" cols="30" rows="10" placeholder="Insira a Descrição"></textarea>
                            <span class="input-border"></span>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>Preço: </td>
                    <td>
                        <div class="form">
                            <input type="number" name="preco" placeholder="Insira o Preço" class="input">
                            <span class="input-border"></span>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>Selecione a Imagem: </td>
                    <td>
                        <input type="file" name="imagem">
                    </td>
                </tr>

                <tr>
                    <td>Categoria: </td>
                    <td>
                        <select name="categoria">
                            <?php
                                $sql = "SELECT * FROM tab_categorias WHERE ativo = 'Sim'";
                                
                                $res = mysqli_query($conn, $sql);
                                $count = mysqli_num_rows($res);

                                if($count > 0) {
                                    while($row = mysqli_fetch_assoc($res)) {
                                        $id = $row['id'];
                                        $titulo = $row['titulo'];
                                        echo "<option value=\"$id\">$titulo</option>";
                                    }
                                } else {
                                    echo "<option value=\"0\">Categoria Não Encontrada</option>";
                                }
                            ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>Apresentar: </td>
                    <td>
                        <input type="radio" name="apresentar" value="Sim"> Sim
                        <input type="radio" name="apresentar" value="Não"> Não
                    </td>
                </tr>

                <tr>
                    <td>Ativo: </td>
                    <td>
                        <input type="radio" name="ativo" value="Sim"> Sim
                        <input type="radio" name="ativo" value="Não"> Não
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" name="comida-add" value="Adicionar Comida" class="btn-primario">
                    </td>
                </tr>
            </table>
        </form>

        <?php
            if(isset($_POST['comida-add'])) {
                $titulo = $_POST['nome_comida'];
                $descricao = $_POST['descricao'];
                $preco = $_POST['preco'];
                $categoria = $_POST['categoria'];

                $apresentar = isset($_POST['apresentar']) ? $_POST['apresentar'] : "Não";
                $ativo = isset($_POST['ativo']) ? $_POST['ativo'] : "Não";

                if(isset($_FILES['imagem']['name'])) {
                    $imagem_nome = $_FILES['imagem']['name'];

                    if($imagem_nome != "") {
                        $partes = explode('.', $imagem_nome);
                        $ext = end($partes);
                        $imagem_nome = "Comida_".rand(000, 999).'.'.$ext;
                        $caminho = $_FILES['imagem']['tmp_name'];
                        $destino = "../image/comidas/".$imagem_nome;
                        $salvar = move_uploaded_file($caminho, $destino);   

                        if($salvar == FALSE) {
                            $_SESSION['upload'] = "<div class='erro'>Erro ao Salvar Imagem </div>";
                            header('location:'.SITEURL.'admin/add-comida');
                            die();
                        }
                    } else {
                        $imagem_nome = "";
                    }
                } else {
                    $imagem_nome = "";
                }

                $sql2 = "INSERT INTO tab_comidas SET
                    titulo = '$titulo',
                    descricao = '$descricao',
                    preco = $preco,
                    nome_imagem = '$imagem_nome',
                    categoria_id = $categoria,
                    apresentar = '$apresentar',
                    ativo = '$ativo'";

                $res2 = mysqli_query($conn, $sql2);

                if($res2 == TRUE) {
                    $_SESSION['salvar'] = "Comida Adicionada com Sucesso";
                    header('location:'.SITEURL.'admin/gerenciar-comidas.php');
                } else {
                    $_SESSION['salvar'] = "<div class='erro'>Erro ao Adicionar Comida</div>";
                    header('location:'.SITEURL.'admin/gerenciar-comidas.php');
                }
            }
        ?>
    </div>
</div>
