<?php
    include('uteis/menu.php');
    include('uteis/rodape.php');
?>

<div class="conteudo">
    <div class="corpo">
        <h1>Editar Administrador</h1>
        <br><br>

            <?php 
            
                $id = $_GET['id'];

                $sql = "SELECT * FROM tab_admin WHERE id = $id";

                $res = mysqli_query($conn, $sql);

                if($res == TRUE)
                {
                        $count = mysqli_num_rows($res);

                        if($count==1)
                        {
                            $row = mysqli_fetch_assoc($res);

                            $nome = $row['nome_completo'];
                            $usuario = $row['nome_user'];
                            $senha = $row['senha'];
                        }
                        else
                        {
                            header('location:'.SITEURL.'admin/pagina-admin.php');
                        }
                }
                else
                {

                }

            ?>

            <form action="" method="POST">

                <table class="tabela-30">
                    <tr>
                        <td>Nome Completo: </td>
                        <td>
                            <div class="form">
                                <input class="input" name="nome" value="<?php echo $nome ?>"  type="text" required>
                                <span class="input-border"></span>
                            </div></td>
                    </tr>
                    <tr>
                        <td>Nome do Usuário: </td>
                        <td>
                            <div class="form">
                                <input class="input" value="<?php echo $usuario ?>" name="usuario"  type="text" required>
                                <span class="input-border"></span>
                            </div>
                        </td>
                    </tr>

                    <tr>

                    <tr>
                        <td colspan="2">
                                <input type="hidden" name="id" value="<?php echo $id; ?>">
                                <input type="submit" name="confirmar" value="Editar" class="btn-primario">
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </div>


    </div>
</div>

<?php 
    if(isset($_POST['confirmar']))
    {
        $id = $_POST['id'];
        $nome_completo = $_POST['nome'];
        $nome_user = $_POST['usuario'];

        $sql = "UPDATE tab_admin SET
        nome_completo = '$nome_completo',
        nome_user = '$nome_user'
        WHERE id = '$id'
        ";

        $res = mysqli_query($conn, $sql);

        if($res==TRUE)
        {

            $_SESSION['editar'] = "Administrador Editado com Sucesso";
            header('location:'.SITEURL.'admin/pagina-admin.php');

        }
        else
        {
            $_SESSION['editar'] = "<div class = 'erro'>Erro ao Editar </div>";
            header('location:'.SITEURL.'admin/pagina-admin.php');
        }
    }


?>