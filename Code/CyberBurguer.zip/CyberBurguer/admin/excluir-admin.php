<?php

    include('../admin/config/conexao.php');

    $id= $_GET['id'];
    
    $sql = "DELETE FROM tab_admin WHERE id=$id";

    $res = mysqli_query($conn, $sql);

    if($res==TRUE)
    {
        $_SESSION['excluir'] = "Administrador Excluído com Sucesso";

        header('location:'.SITEURL.'admin/pagina-admin.php');
    }
    else
    {
        $_SESSION['excluir'] = "<div class = 'erro'>Erro ao Excluir Administrador</div>";
        header('location:'.SITEURL.'admin/pagina-admin.php');
    }

?>