<?php
    include('../admin/config/conexao.php');
    include('uteis/rodape.php');
?>
<html>
    <head>
        <title>Login - CyberFood</title>
        <link rel="stylesheet" href="../css/admin.css">
    </head>

    <body>
            <div class="login centralizar">
                <h1>Entrar</h1>
                <br><br>
                <?php
                        if(isset($_SESSION['login'])){
                            echo $_SESSION['login'];
                            unset($_SESSION['login']);
                        }
                        if(isset($_SESSION['mensagem-login'])){
                            echo $_SESSION['mensagem-login'];
                            unset($_SESSION['mensagem-login']);
                        }
                ?>
                
                <form action="" method="POST">
                    Nome de Usuario:
                    <br><br>
                    <div class="form">
                                    <input class="input centralizar" name="nome_user"  type="text" placeholder="Insira Nome do Usuário" required>
                                    <span class="input-border"></span>
                                </div>
                            <br><br>
                    Senha:
                    <div class="form">
                                <input class="input centralizar" name="senha"  type="password" placeholder="Insira a Senha" required>
                                <span class="input-border"></span>
                        </div>
                        <br><br><br><br>
                        <input type="submit" name="login" value="Entrar" class="btn-primario">

                </form>
            </div>
    </body>
</html>

<?php
    if(isset($_POST['login'])){
        $nome_user = $_POST['nome_user'];
        $senha = $_POST['senha'];

        $sql = "SELECT * FROM tab_admin WHERE nome_user = '$nome_user' AND senha = '$senha'";

        $res = mysqli_query($conn, $sql);

        $count = mysqli_num_rows($res);

        if($count == 1)
        {
            $_SESSION['login'] = "Login Efetuado";
            $_SESSION['usuario'] = $nome_user;
            header('location:'.SITEURL.'admin/');
        }
        else
        {
            $_SESSION['login'] = "<div class = 'erro centralizar'>Usuário ou Senha Incorreto</div><br>";
            header('location'.SITEURL.'admin/login.php');
        }

        
    }
?>