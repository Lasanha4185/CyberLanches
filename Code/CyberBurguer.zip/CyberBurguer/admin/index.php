<!--Aqui o menu será inserido-->
<?php include('uteis/menu.php'); ?>
<head>
    <title>CyberFood - Home</title>
</head>
        <div class="conteudo">
            <div class="corpo">
            <?php
                    
                    if(isset($_SESSION['login']))
                    {
                        echo $_SESSION['login'];
                        unset ($_SESSION['login']);
                    }?>
                <h1>DASHBOARD</h1>
                <div class = "col-4 centralizar">
                   
                        <?php
                                $sql = "SELECT * FROM tab_admin";
                                $res = mysqli_query($conn, $sql);

                                if($res == TRUE){
                                    $count = mysqli_num_rows($res);

                                    if($count>0)
                                    {
                                        while($rows=mysqli_fetch_assoc($res))
                                        {
                                            $id=$rows['id'];
                                            $nome_completo = $rows['nome_completo'];
                                            $nome_user = $rows['nome_user'];

                                            //Mostrando as informações
                                            ?>
                                            
                                            <?php
                                            
                                            
                                        }
                                    }
                                    else
                                    {

                                    }
                                }
                            ?>
                            <h1><?php echo $count;?></h1>
                            <br>
                            Administradores
                </div>
                <div class = "col-4 centralizar">
                <?php
                                $sql = "SELECT * FROM tab_categorias";
                                $res = mysqli_query($conn, $sql);

                                if($res == TRUE){
                                    $count = mysqli_num_rows($res);

                                    if($count>0)
                                    {
                                        while($rows=mysqli_fetch_assoc($res))
                                        {
                                            $id=$rows['id'];
                                            ?>
                                            
                                            <?php
                                            
                                            
                                        }
                                    }
                                }
                            ?>
                            <h1><?php echo $count;?></h1>
                    <br/>
                    Categorias
                </div>

                <div class = "col-4 centralizar">
                <?php
                                $sql = "SELECT * FROM tab_comidas";
                                $res = mysqli_query($conn, $sql);

                                if($res == TRUE){
                                    $count = mysqli_num_rows($res);

                                    if($count>0)
                                    {
                                        while($rows=mysqli_fetch_assoc($res))
                                        {
                                            $id=$rows['id'];
                                            ?>
                                            
                                            <?php
                                            
                                            
                                        }
                                    }
                                }
                            ?>
                            <h1><?php echo $count;?></h1>
                    <br/>
                   
                    Comidas
                </div>

                <div class = "col-4 centralizar">
                <?php    $sql = "SELECT * FROM tab_pedido";
                                    $res = mysqli_query($conn, $sql);

                                    if($res == TRUE){
                                        $count = mysqli_num_rows($res);

                                        if($count>0)
                                        {
                                            while($rows=mysqli_fetch_assoc($res))
                                            {
                                                $id=$rows['id'];
                                                ?>
                                                
                                                <?php
                                                
                                                
                                            }
                                        }
                                    }
                                ?>
                                <h1><?php echo $count;?></h1>
                    <br />
                    Pedidos
                </div>

                <div class="clearfix"></div>

            </div>
        </div>
<!--Já aqui o rodapé será inserido, como tanto o menu como o rodapé serão usando muitas vezes criaremos eles separadamentes e depois incluiremos eles assim usando a recursividade-->        
<?php include('uteis/rodape.php'); ?>
