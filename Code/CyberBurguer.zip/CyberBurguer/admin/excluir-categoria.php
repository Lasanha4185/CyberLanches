<?php
    include('../admin/config/conexao.php');

    if(isset($_GET['id']) AND isset($_GET['nome_imagem']))
    {
        $id = $_GET['id'];
        $nome_imagem = $_GET['nome_imagem'];

        if($nome_imagem !="")
        {
            $caminho = "../image/categorias/".$nome_imagem;
            $remove = unlink($caminho);

            if($remove==FALSE)
            {
                $_SESSION['remove'] = "<div class='erro'>Erro ao Remover<br><br></div>";

                header('location:'.SITEURL.'admin/gerenciar-categoria.php');

                die();

            }
        }

        $sql = "DELETE FROM tab_categorias WHERE id = $id";

        $res = mysqli_query($conn, $sql);

        if($res == TRUE)
        {
            $_SESSION['delete'] = "Deletado com Sucesso";

            header('location:'.SITEURL.'admin/gerenciar-categoria.php');

        }
        else
        {
            $_SESSION['delete'] = "<div class='erro'>Erro ao Excluir</div>";

            header('location:'.SITEURL.'admin/gerenciar-categoria.php');
        }

    }
    else
    {
        header('location:'.SITEURL.'admin/gerenciar-categoria.php');
    }
?>