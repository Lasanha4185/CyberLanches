<!--Aqui o menu será inserido-->
<?php include('uteis/menu.php'); ?>
<head>
    <title>CyberFood - Administrador</title>
</head>
            <div class="conteudo">
                <div class="corpo">

                    <h1>Gerenciar Administrador</h1>

                    <br><br>
                    
                    <?php
                        if(isset($_SESSION['add'])){
                            echo $_SESSION['add'];
                            unset($_SESSION['add']);
                        }
                        if(isset($_SESSION['excluir'])){
                            echo $_SESSION['excluir'];
                            unset($_SESSION['excluir']);
                        }
                        if(isset($_SESSION['editar'])){
                            echo $_SESSION['editar'];
                            unset($_SESSION['editar']);
                        }
                        if(isset($_SESSION['usuario-nao-encontrado'])){
                            echo $_SESSION['usuario-nao-encontrado'];
                            unset($_SESSION['usuario-nao-encontrado']);
                        }
                        if(isset($_SESSION['senha-nao-bate'])){
                            echo $_SESSION['senha-nao-bate'];
                            unset($_SESSION['senha-nao-bate']);
                        }
                        if(isset($_SESSION['senha-trocada'])){
                            echo $_SESSION['senha-trocada'];
                            unset($_SESSION['senha-trocada']);
                        }
                        if(isset($_SESSION['erro_senha'])){
                            echo $_SESSION['erro_senha'];
                            unset($_SESSION['erro_senha']);
                        }

                    ?>
                    <br><br><br>

                    <a href="add-admin.php" class="btn-primario">Adicionar Administrador</a>

                    <br><br><br>

                    <table class="tabela">
                        <tr>
                            <th>ID</th>
                            <th>Nome Completo</th>
                            <th>Nome de Usuário</th>
                            <th>Ações</th>
                        </tr>

                        <?php
                            $sn = 1; 
                            $sql = "SELECT * FROM tab_admin";
                            $res = mysqli_query($conn, $sql);

                            if($res == TRUE){
                                $count = mysqli_num_rows($res);

                                if($count>0)
                                {
                                    while($rows=mysqli_fetch_assoc($res))
                                    {
                                        $id=$rows['id'];
                                        $nome_completo = $rows['nome_completo'];
                                        $nome_user = $rows['nome_user'];

                                        //Mostrando as informações
                                        ?>
                                        <tr>
                                            <td><?php echo $sn++ ?></td>
                                            <td><?php echo $nome_completo ?></td>
                                            <td><?php echo $nome_user ?></td>
                                            <td>
                                            <a href="<?php echo SITEURL ?>admin/editar-senha.php?id=<?php echo $id;?>" class="btn-primario">Editar Senha</a>
                                                <a href="<?php echo SITEURL ?>admin/editar-admin.php?id=<?php echo $id;?>" class="btn-secundario">Editar</a>
                                                <a href="<?php echo SITEURL ?>admin/excluir-admin.php?id=<?php echo $id;?>" class="btn-danger">Excluir</a>
                                            </td>
                                        </tr>
                                        <?php
                                        
                                        
                                    }
                                }
                                else
                                {

                                }
                            }
                        ?>


                    
                    </table>

                </div>
            </div>
<!--Já aqui o rodapé será inserido-->
<?php include('uteis/rodape.php'); ?>