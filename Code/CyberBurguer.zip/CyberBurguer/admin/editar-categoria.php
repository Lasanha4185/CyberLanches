<?php
    include('uteis/menu.php');
    include('uteis/rodape.php');
?>
<head><title>Editar Categoria</title></head>
<?php
    if(isset($_GET['id'])) {
        $id = $_GET['id'];

        $sql = "SELECT * FROM tab_categorias WHERE id=$id";
        $res = mysqli_query($conn, $sql);
        $count = mysqli_num_rows($res);

        if($count == 1) {
            $row = mysqli_fetch_assoc($res);
            $titulo = $row['titulo'];
            $imagem_atual = $row['nome_imagem'];
            $apresentar = $row['apresentar'];
            $ativo = $row['ativo'];
        } else {
            $_SESSION['categoria-nao-encontrada'] = "<div class='erro'>Categoria não Encontrada<br><br></div>";
            header('location:'.SITEURL.'admin/gerenciar-categoria.php');
        }
    } else {
        header('location:'.SITEURL.'admin/gerenciar-categoria.php');
    }
?>

<div class="conteudo">
    <div class="corpo">
        <form action="" method="POST" enctype="multipart/form-data">
            <table class="tabela-30">
                <tr>
                    <td>Categoria: </td>
                    <td>
                        <div class="form">
                            <input class="input" name="titulo" value="<?php echo $titulo ?>" type="text" required>
                            <span class="input-border"></span>
                        </div>
                    </td>
                </tr>

                <tr>
                    <td>Imagem Atual</td>
                    <td>
                        <?php if($imagem_atual != "") { ?>
                            <img src="<?php echo SITEURL; ?>image/categorias/<?php echo $imagem_atual; ?>" width="150px">
                        <?php } ?>
                    </td>
                </tr>

                <tr>
                    <td>Nova Imagem</td>
                    <td>
                        <input type="file" name="imagem">
                    </td>
                </tr>

                <tr>
                    <td>Apresentar: </td>
                    <td>
                        <input <?php if($apresentar == "Sim") { echo "checked"; } ?> type="radio" name="apresentar" value="Sim"> Sim
                        <input <?php if($apresentar == "Não") { echo "checked"; } ?> type="radio" name="apresentar" value="Não"> Não
                    </td>
                </tr>

                <tr>
                    <td>Ativo: </td>
                    <td>
                        <input <?php if($ativo == "Sim") { echo "checked"; } ?> type="radio" name="ativo" value="Sim"> Sim
                        <input <?php if($ativo == "Não") { echo "checked"; } ?> type="radio" name="ativo" value="Não"> Não
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="hidden" name="imagem_atual" value="<?php echo $imagem_atual; ?>">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <input type="submit" name="categoria-editar" value="Salvar" class="btn-primario">
                    </td>
                </tr>
            </table>
        </form>

        <?php
            if(isset($_POST['categoria-editar'])) {
                $id = $_POST['id'];
                $titulo = $_POST['titulo'];
                $imagem_atual = $_POST['imagem_atual'];
                $apresentar = $_POST['apresentar'];
                $ativo = $_POST['ativo'];

                if(isset($_FILES['imagem']['name'])) {
                    $imagem_nome = $_FILES['imagem']['name'];

                    if($imagem_nome != "") {
                        $partes = explode('.', $imagem_nome);
                        $ext = end($partes);

                        $imagem_nome = "Categoria_".rand(000, 999).'.'.$ext;
                        $caminho = $_FILES['imagem']['tmp_name'];
                        $destino = "../image/categorias/".$imagem_nome;

                        $salvar = move_uploaded_file($caminho, $destino);

                        if($salvar == FALSE) {
                            $_SESSION['upload'] = "<div class='erro'>Erro ao Salvar Imagem <br><br><br></div>";
                            header('location:'.SITEURL.'admin/gerenciar-categoria.php');
                            die();
                        }

                        if($imagem_atual != "") {
                            $remove_caminho = "../image/categorias/".$imagem_atual;
                            $remove = unlink($remove_caminho);

                            if($remove == FALSE) {
                                $_SESSION['falha-remove'] = "<div class='erro'>Falha ao Editar Imagem Atual<br><br><br></div>";
                                header('location:'.SITEURL.'admin/gerenciar-categoria.php');
                                die();
                            }
                        }
                    } else {
                        $imagem_nome = $imagem_atual;
                    }
                } else {
                    $imagem_nome = $imagem_atual;
                }

                $sql2 = "UPDATE tab_categorias SET 
                            titulo = '$titulo',
                            nome_imagem = '$imagem_nome',
                            apresentar = '$apresentar',
                            ativo = '$ativo'
                         WHERE id=$id";

                $res2 = mysqli_query($conn, $sql2);

                if($res2 == TRUE) {
                    $_SESSION['editar'] = "Categoria Editada com Sucesso";
                    header('location:'.SITEURL.'admin/gerenciar-categoria.php');
                } else {
                    $_SESSION['editar'] = "<div class='erro'>Falha ao Editar Categoria</div>";
                    header('location:'.SITEURL.'admin/gerenciar-categoria.php');
                }
            }
        ?>
    </div>
</div>
