<?php
   include ('../CyberBurguer/admin/config/conexao.php');
   date_default_timezone_set("America/Sao_Paulo");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $input = file_get_contents('php://input');
    $dados = json_decode($input, true);

    $nome = $dados['name'];
    $contato = $dados['contact'];
    $endereco = $dados['address'];
    $cartItems = $dados['cartItems'];

    foreach ($cartItems as $item) {
      $comida = $item['titulo'];
      $quantidade = $item['quantidade'];
      $preco = $item['preco'];
      $total = $preco * $quantidade;
      $dataAtual = date(DATE_ATOM);
        
      $sql2 = "INSERT INTO tab_pedido SET
          cliente_endereco = '$endereco',
          nome_cliente = '$nome',
          cliente_contato = '$contato',
          quantidade = '$quantidade',
          data_pedido = '$dataAtual',
          comida = '$comida',
          preco = '$preco',
          total = '$total'";

      $res2 = $conn->query($sql2);

      if ($res2 !== TRUE) {
          echo json_encode([
              'success' => false,
              'message' => "Erro ao adicionar o pedido: " . $conn->error
          ]);
          exit();
        }
    }


     //$res2 = mysqli_query($conn, $sql2);

    //     if($res2 == TRUE) {
     //         $_SESSION['salvar'] = "Comida Adicionada com Sucesso";
    //         header('location:'.SITEURL.'admin/gerenciar-comidas.php');
    //     } else {
    //         $_SESSION['salvar'] = "<div class='erro'>Erro ao Adicionar Comida</div>";
    //         header('location:'.SITEURL.'admin/gerenciar-comidas.php');
    //     }
    echo json_encode([
        'nome' => $nome,
        'contato' => $contato,
        'email' => $contato,
        'endereco' => $endereco,
        'cartItems' => $cartItems
    ]);
}
?>