const scrollAnima = document.querySelectorAll('[data-anima="scroll"]');
const metadeWindow = window.innerHeight * 4;



function animarScroll() {
    scrollAnima.forEach(item => {
        const topoItem = item.getBoundingClientRect().top;
        const itemVisivel = topoItem - metadeWindow < 0;

        if (itemVisivel) {
            item.classList.add('show-button');
        } else {
            item.classList.remove('show-button');
        }
    });
}

window.addEventListener('scroll', animarScroll);


document.getElementById('customer-contact').addEventListener('input', function (event) {
    let input = this.value.replace(/\D/g, '').substring(0, 13);
    let countryCode = input.substring(0, 2);
    let areaCode = input.substring(2, 4);
    let firstPart = input.substring(4, 8);
    let secondPart = input.substring(8, 13);
    if (input.length > 8) {
        this.value = `+${countryCode} (${areaCode}) ${firstPart}-${secondPart}`;
    } else if (input.length > 4) {
        this.value = `+${countryCode} (${areaCode}) ${firstPart}`;
    } else if (input.length > 2) {
        this.value = `+${countryCode} (${areaCode}`;
    } else if (input.length > 0) {
        this.value = `+${countryCode}`;
    }
});


// document.getElementById('customer-form').addEventListener('submit', function(event) {
//     event.preventDefault();
//     const finalizeButton = document.getElementById('finalize-purchase-button');
//     finalizeButton.disabled = false;
//     alert('Dados enviados com sucesso!');
// });

document.getElementById('finalize-purchase-button').addEventListener('click', function() {
    if (!this.disabled) {
        alert('Compra finalizada com sucesso!');
        // Lógica para finalizar a compra
    } else {
        alert('Por favor, preencha os dados do cliente primeiro.');
    }
});