<?php 
    include ('../CyberBurguer/admin/config/conexao.php');
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>


    
    <link rel="shortcut icon" href="imagens/cyberfood.ico" type="image/x-icon">
    <meta charset="UTF-8">
  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@500&family=Fuggles&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <title>Cyber-Food</title>
</head>
<body>


    <header class="content" id="topo">
        <a href="../CyberBurguer/index.php">
            <div class="logo">
                <img src="imagens/cyberfood.png">
                <h3>Cyber-Food</h3>
            </div>
        </a>
        <nav>
            <ul class="list-menu">
               <li><a href="#topo" class="links">Home</a></li>
               <li><a href="#sobrenos" class="links">Sobre nós</a></li>
               <li><a href="#cardapio" class="links">Pratos</a></li>
               <li><a href="#contatos" class="links">Contato</a></li>
               <li><a href="" target="_blank" class="links"><i class="bi bi-instagram"></i></a></li>
               <li><a href="loja.php" class="links" id="cart-icon"><i class="bi bi-cart2"></i></a></li>
                    
                
                
                



            </ul>
        </nav>



        <div class="menu-toggle">
            <div class="one"></div>
            <div class="two"></div>
            <div class="three"></div>

        </div>
    </header>
 
      
      
      

    <section class="first-section">
        <div class="conteudo-principal">
            <h1>Aproveite a estadia no melhor restaurante</h1>
            <h2>Garanta já o seu</h2>
            <div class="btn">
                <a href="#contatos" class="links"><button class="reservar">Marque aqui!</button></a>
                <a href="#cardapio" class="links"> <button class="montar">Escolha</button></a>

            </div>

        </div>
    </section>

    <section class="sobre-nos" id="sobrenos">
        <div class="main">

            <div class="contentsobre">
                <h2>Sobre nós</h2>
                <p>
                   
Bem-vindo ao Cyber-Food o sabor de João Pessoa, o seu destino definitivo para uma experiência gastronômica irresistível! Localizado no coração da cidade, nosso restaurante oferece pizzas, hambúrgueres e frango frito preparados com ingredientes frescos e de alta qualidade. Nossas pizzas têm massa fermentada naturalmente e combinações surpreendentes; os hambúrgueres são grelhados à perfeição e servidos em pães artesanais; e o frango frito é crocante e suculento, graças à nossa receita secreta. Com um ambiente acolhedor e familiar, somos o local perfeito para encontros casuais ou celebrações especiais.  </p>
            </div>
            <div class="img-cozinha">
                <img src="./imagens/food_porn_hamburguer.jpg" alt="">

            </div>
            

            <div class="triangulo-invertido"></div>
            <div class="setaBaixo"></div>
           
        </div>
    
    </section>


    <section class="second-section">
        <div class="overlay"></div>
    </section>
   
    <section class="cardapio" id="cardapio">
    <h2>Pratos Principais</h2>
    <div class="itens-cardapio">
        <?php
            $sql = "SELECT * FROM tab_comidas";
            $res = mysqli_query($conn, $sql);

            if($res == TRUE){
                $count = mysqli_num_rows($res);

                if($count > 0) {
                    // Inicializa uma variável para controlar a contagem de itens
                    $item_count = 0;

                    while($rows = mysqli_fetch_assoc($res)) {
                        $id = $rows['id'];
                        $titulo = $rows['titulo'];
                        $descricao = $rows['descricao'];
                        $preco = $rows['preco'];
                        $nome_imagem = $rows['nome_imagem'];
                        $apresentar = $rows['apresentar'];
                        $ativo = $rows['ativo'];

                        //Mostrando as informações
                        ?>
                        <div class="item">
                            <img src="<?php echo SITEURL; ?>image/comidas/<?php echo $nome_imagem; ?>" alt="">
                            <div class="info">
                                <h3><?php echo $titulo ?></h3>
                                <h3><?php echo $descricao?></h3>
                                <h3>R$<?php echo $preco ?></h3>
                                <a href="loja.php"><button class="pedir">Pedir agora</button></a>
                            </div>
                        </div>
                        <?php
                        // Incrementa a contagem de itens
                        $item_count++;

                        // Verifica se já exibiu dois itens e se sim, fecha o contêiner atual
                        if ($item_count % 2 == 0 && $item_count != $count) {
                            echo '</div><div class="itens-cardapio">';
                        }
                    }
                }
            }
        ?>
    </div>
</section>


   <section class="contatos" id="contatos">
    <h3>Contatos</h3>
    <div class="contatos-secao">
        <div>
            <i class="bi bi-telephone"></i>
            <span>(83)5555-5555</span>
        </div>
        <div>
            <i class="bi bi-instagram"></i>
            <span>CyberFood</span>
        </div>
        <div>
            <i class="bi bi-facebook"></i>
            <span>CyberFood</span>
        </div>
    </div>
   </section>
   <section class="contatos2" id="contatos2"></section>


   <div data-scroll="suave" data-anima="scroll">
      <a href="#topo">
        <div class="topo">
            <img src="./imagens/circle-up.png" alt="Voltar ao topo">
        </div>

     </a>

   </div>

    <script src="scroll-suave.js"></script>
    <script src="script.js"></script>
     <script src="Menu.js"></script>
     <script src="carrinho.js"></script>
</body>
</html>