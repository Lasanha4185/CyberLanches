



<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="teste.css">
    <link rel="shortcut icon" href="imagens/cyberfood.ico" type="image/png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@500&family=Fuggles&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <script src="loja.js" async></script> 
    <title>Cyber-Food</title>
</head>
<body>
    <header class="content" id="topo">
        <a href="index.php">
            <div class="logo">
                <img src="imagens/cyberfood.png" alt="Cyber-Food Logo">
                <h3>Cyber-Food</h3>
            </div>
        </a>
        <nav>
            <ul class="list-menu">
                <li><a href="#topo" class="links">Home</a></li>
                <li><a href="#contatos" class="links">Contato</a></li>
                <li><a href="" target="_blank" class="links"><i class="bi bi-instagram"></i></a></li>
            </ul>
        </nav>
        <div class="menu-toggle">
            <div class="one"></div>
            <div class="two"></div>
            <div class="three"></div>
        </div>
    </header>
    <main class="main-section">
        <section class="container normal-section">
            <div class="products-container">

    <?php
    include ('../CyberBurguer/admin/config/conexao.php');

    $sql = "SELECT * FROM tab_comidas";
    $res = mysqli_query($conn, $sql);

    if($res == TRUE) {
        $count = mysqli_num_rows($res);

        if($count > 0) {
            while($rows = mysqli_fetch_assoc($res)) {
                $id = $rows['id'];
                $titulo = $rows['titulo'];
                $descricao = $rows['descricao'];
                $preco = $rows['preco'];
                $nome_imagem = $rows['nome_imagem'];
                $apresentar = $rows['apresentar'];
                $ativo = $rows['ativo'];
                ?>
                            <div class="movie-product">
                                <br><br><br>
                                <strong class="product-title" name="nome_comida" class="nome_comida" id="nome_comida"><?php echo $titulo; ?></strong>
                                <img src="<?php echo SITEURL; ?>image/comidas/<?php echo $nome_imagem; ?>" alt="<?php echo $titulo; ?>" class="product-image">
                                <div class="product-price-container">
                                    <span class="product-price">R$<?php echo $preco; ?></span>
                                    <button type="button" class="button-hover-background">Adicionar ao carrinho</button>
                                </div>
                            </div>
                <?php
            }
        }
    }
    ?>
            </div>
        </section>
    </main>

    <section class="container normal-section">
        <h2 class="section-title">Carrinho</h2>
        <table class="cart-table">
            <thead>
                <tr>
                    <th class="table-head-item first-col">Item</th>
                    <th class="table-head-item second-col">Preço</th>
                    <th class="table-head-item third-col">Quantidade</th>
                </tr>
            </thead>
            <tbody>
                <!-- Os itens do carrinho serão inseridos aqui -->
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="cart-total-container">
                        <strong>Total</strong>
                        <span>R$0,00</span>
                    </td>
                </tr>
            </tfoot>
        </table>
    </section>

    <section class="container customer-section">
    <h2 class="section-title">Dados do Cliente</h2>
    <form id="customer-form" method="POST" action="former.php">
        <label for="customer-name">Nome:</label>
        <input type="text" id="customer-name" name="customer-name" required>
        <label for="customer-contact">Contato:</label>
        <input type="tel" id="customer-contact" name="customer-contact" placeholder="+55 (83) 5555-5555" required>
        <label for="customer-address">Endereço:</label>
        <input type="text" id="customer-address" name="customer-address" required>
        <input type="hidden" id="cart-items" name="cart-items">

        <input type="submit" name="finalizar" value="finalizar" class="purchase-button" name="finalize-purchase-button" >
    </form>
</section>

    <section class="contatos" id="contatos">
        <h3>Contatos</h3>
        <div class="contatos-secao">
            <div>
                <i class="bi bi-telephone"></i>
                <span>(83)5555-5555</span>
            </div>
            <div>
                <i class="bi bi-instagram"></i>
                <span>CyberFood</span>
            </div>
            <div>
                <i class="bi bi-facebook"></i>
                <span>CyberFood</span>
            </div>
        </div>
    </section>
    <section class="contatos2" id="contatos2"></section>
    <div data-scroll="suave" data-anima="scroll">
        <a href="#topo">
            <div class="topo">
                <img src="./imagens/circle-up.png" alt="Voltar ao topo">
            </div>
        </a>
    </div>

    <script src="scroll-suave.js"></script>
    <!-- <script src="script.js"></script> -->
    <script src="Menu.js"></script>
</body>
</html>

